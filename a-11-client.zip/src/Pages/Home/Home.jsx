import Footer from "../Footer/Footer";
import Newsletter from "./Newsletter";
// import Rooms from "./Rooms";



const Home = () => {
    return (
        <div>
           {/* <Rooms></Rooms>  */}
           <Newsletter></Newsletter>  
           <Footer></Footer>    
        </div>
    );
};

export default Home;