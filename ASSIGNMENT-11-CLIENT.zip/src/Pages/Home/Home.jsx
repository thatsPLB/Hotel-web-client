import Footer from "../Footer/Footer";
import Banner from "./Banner";
import Newsletter from "./Newsletter";
// import Rooms from "./Rooms";



const Home = () => {
    return (
        <div>
           {/* <Rooms></Rooms>  */}
           <Banner></Banner>
           <Newsletter></Newsletter>  
           <Footer></Footer>    
        </div>
    );
};

export default Home;